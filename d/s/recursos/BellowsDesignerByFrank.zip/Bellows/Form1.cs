// Bellows - bellows fold pattern printer, based on US Patent No 6,054,194,
// Mathematically optimized family of ultra low distortion bellow fold patterns, Nathan R. Kane.
// Copyright (C) 2008, Frank Tkalcevic, www.franksworkshop.com

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

namespace Bellows
{
	public partial class Form1 : Form
	{
		double dblPaperWidth;
		int nFolds;
		int nPage;
		int nPages;
		Configuration m_Config;
		BellowsConfigElement m_CurrentElement;
		bool m_bCalculationError;

		public Form1()
		{
			m_bCalculationError = true;
			InitializeComponent();

			cboShape.Items.Add(BellowsConfigElement.EBellowsShape.HalfCover);
			cboShape.Items.Add(BellowsConfigElement.EBellowsShape.EnclosedBox);

			cboInversions.Items.Add(1);
			cboInversions.Items.Add(2);
			cboInversions.Items.Add(3);
			cboInversions.Items.Add(4);

			m_Config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

			BellowConfig cfg = (BellowConfig)m_Config.Sections["BellowConfig"];
			if (cfg == null)
			{
				cfg = new BellowConfig();
				m_Config.Sections.Add("BellowConfig", cfg);
				cfg = (BellowConfig)m_Config.Sections["BellowConfig"];
				cfg.SectionInformation.ForceSave = true;
			}

			foreach (BellowsConfigElement b in cfg.Bellows)
			{
				cboConfig.Items.Add(b);
			}
			int nItem = cboConfig.FindStringExact( ((BellowConfig)m_Config.Sections["BellowConfig"]).SelectedItem );
            if (nItem >= 0)
                cboConfig.SelectedIndex = nItem;
            else
            {
                if ( cboConfig.Items.Count > 0 )
                    cboConfig.SelectedIndex = 0;
            }

			printDocument1.PrinterSettings = printDialog1.PrinterSettings;

			UpdateCalculations();
		}

		private bool UpdateCalculations()
		{
			bool bRet = false;
			try
			{
				double dblLength = double.Parse(txtLength.Text);
				double dblFoldWidth = double.Parse(txtFoldWidth.Text);
				int nMountFolds = int.Parse(txtMountFolds.Text);
				double dblExtensionAngle = 120.0;
				double dblWidth = double.Parse(txtWidth.Text);
				double dblHeight = double.Parse(txtHeight.Text);

				// Compute the number of folds 
				// = Length / (FoldWidth*sin(120))
				double dblFolds = dblLength / (dblFoldWidth * Math.Sin(dblExtensionAngle / 2 / 180 * Math.PI));
				nFolds = (int)(dblFolds + 1.0);
				// Round up to even number.
				if ((nFolds & 1) == 1)
					nFolds++;
				// Then add mount folds
				nFolds += nMountFolds;

				// Use width and height to calculate fold dimensions
				double dblTopWidth = dblWidth + 2 * dblFoldWidth;
				double dblSideHeight = dblHeight + dblFoldWidth;

				dblPaperWidth = dblTopWidth + 2 * dblSideHeight;

				lblPageWidth.Text = dblPaperWidth.ToString() + " mm";
				lblPageHeight.Text = ((double)nFolds * dblFoldWidth).ToString() + "mm";


				bRet = true;
				m_bCalculationError = false;
			}
			catch (Exception )
			{
				bRet = false;
				m_bCalculationError = true;
			}

			panel1.Invalidate();
			return bRet;
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
			DrawBellows(e.Graphics);
		}

		private void DrawBellows( Graphics g )
		{
			double dblFoldWidth;
			double dblHeight;

            if (!double.TryParse(txtFoldWidth.Text, out dblFoldWidth))
                return;

            if (!double.TryParse(txtHeight.Text, out dblHeight))
                return;

            double dblPaperHeight = (double)nFolds * dblFoldWidth;

            Pen oSolidPen;
			Pen oDottedPen;
			if (!m_bCalculationError)
			{
				oSolidPen = new Pen(Color.Black, 0.25f);
				oDottedPen = new Pen(Color.Black, 0.25f);
			}
			else
			{
				oSolidPen = new Pen(Color.Red, 0.25f);
				oDottedPen = new Pen(Color.Red, 0.25f);
			}

			oDottedPen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;

			double a1 = 72.57 / 180.0 * Math.PI;
			double a2 = 27.57 / 180.0 * Math.PI;

			double x1 = dblHeight + dblFoldWidth;
			double x2 = dblPaperWidth - x1;

			bool bAlternate = chkAlternateFolds.Checked;

			g.DrawRectangle(oSolidPen, 0, 0, (float)dblPaperWidth, (float)dblPaperHeight);
			g.DrawLine(oSolidPen, 0, 0, (float)dblPaperWidth, (float)dblPaperHeight);
			for (int i = 0; i < nFolds; i += 2)
			{
				double dxa1 = dblFoldWidth / Math.Tan(a1);
				double dxa2 = dblFoldWidth / Math.Tan(a2);

				double y = (double)(i + 1) * dblFoldWidth;
				g.DrawLine(oSolidPen, 0, (float)y, (float)dblPaperWidth, (float)y);
				g.DrawLine(oSolidPen, 0, (float)(y - dblFoldWidth), 0, (float)(float)(y + dblFoldWidth));
				g.DrawLine(oSolidPen, (float)dblPaperWidth, (float)(y - dblFoldWidth), (float)dblPaperWidth, (float)(float)(y + dblFoldWidth));

				double dblAlt = 1.0;
				if (bAlternate)
					if ((i & 2) == 0)
						dblAlt = 1.0;
					else
						dblAlt = -1.0;

				g.DrawLine(oDottedPen, 0, (float)(y + dblFoldWidth), (float)(x1 - dblAlt * dxa2), (float)(y + dblFoldWidth));
				g.DrawLine(oSolidPen, (float)(x1 - dblAlt * dxa2), (float)(y + dblFoldWidth), (float)(x1 - dblAlt * dxa1), (float)(y + dblFoldWidth));
				g.DrawLine(oDottedPen, (float)(x1 - dblAlt * dxa1), (float)(y + dblFoldWidth), (float)(x2 + dblAlt * dxa1), (float)(y + dblFoldWidth));
				g.DrawLine(oSolidPen, (float)(x2 + dblAlt * dxa1), (float)(y + dblFoldWidth), (float)(x2 + dblAlt * dxa2), (float)(y + dblFoldWidth));
				g.DrawLine(oDottedPen, (float)(x2 + dblAlt * dxa1), (float)(y + dblFoldWidth), (float)(dblPaperWidth), (float)(y + dblFoldWidth));


				if ( bAlternate )
					if ( (i&2)== 0 )
						dblAlt = -1.0;
					else
						dblAlt = 1.0;

				g.DrawLine(oDottedPen, (float)(x1 - dblAlt*dxa2), (float)(y - dblFoldWidth), (float)(x1), (float)(y));
				g.DrawLine(oSolidPen, (float)(x1 - dblAlt * dxa1), (float)(y - dblFoldWidth), (float)(x1), (float)(y));
				g.DrawLine(oDottedPen, (float)(x2 + dblAlt * dxa2), (float)(y - dblFoldWidth), (float)(x2), (float)(y));
				g.DrawLine(oSolidPen, (float)(x2 + dblAlt * dxa1), (float)(y - dblFoldWidth), (float)(x2), (float)(y));

				if (bAlternate) 
					if ( (i & 2) == 0)
						dblAlt = 1.0;
					else
						dblAlt = -1.0;

				g.DrawLine(oDottedPen, (float)(x1 - dblAlt * dxa2), (float)(y + dblFoldWidth), (float)(x1), (float)(y));
				g.DrawLine(oSolidPen, (float)(x1 - dblAlt * dxa1), (float)(y + dblFoldWidth), (float)(x1), (float)(y));
				g.DrawLine(oDottedPen, (float)(x2 + dblAlt * dxa2), (float)(y + dblFoldWidth), (float)(x2), (float)(y));
				g.DrawLine(oSolidPen, (float)(x2 + dblAlt * dxa1), (float)(y + dblFoldWidth), (float)(x2), (float)(y));
			}

		}

		private void btnPrint_Click(object sender, EventArgs e)
		{
			UpdateCalculations();
			printPreviewDialog1.Document = printDocument1;
			nPage = 0;
			if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
			{
			}
		}

		private void btnPrintSetup_Click(object sender, EventArgs e)
		{
			UpdateCalculations();
			printDialog1.Document = printDocument1;
			if (printDialog1.ShowDialog() == DialogResult.OK)
			{
				nPage = 0;
				printDocument1.Print();
			}
		}

		double dblPageWidth;
		double dblPageHeight;
		int nPartsVertical;
		int nPartsHorizontal;

		private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
		{
			if (nPage == 0)
			{
				// First page.  Compute the number of pages we will need.
				if (e.PageSettings.Landscape)
				{
					dblPageWidth = (double)e.PageSettings.PrintableArea.Height * 25.4 / 100.0;
					dblPageHeight = (double)e.PageSettings.PrintableArea.Width * 25.4 / 100.0;
				}
				else
				{
					dblPageWidth = (double)e.PageSettings.PrintableArea.Width * 25.4 / 100.0;
					dblPageHeight = (double)e.PageSettings.PrintableArea.Height * 25.4 / 100.0;
				}

				// 10mm overlap.
				dblPageWidth -= 10;
				dblPageHeight -= 10;

				double dblFoldWidth = double.Parse(txtFoldWidth.Text);
				double dblPaperHeight = (double)nFolds * dblFoldWidth;

				// Parts vertically.
				nPartsVertical = (int)(dblPaperHeight / dblPageHeight + 1.0);

				// Parts horizontal.
				nPartsHorizontal = (int)(dblPaperWidth / dblPageWidth + 1.0);

				nPages = nPartsVertical * nPartsHorizontal;
			}

			int nPageX = nPage / nPartsVertical;
			int nPageY = nPage % nPartsVertical;

			e.Graphics.PageUnit = GraphicsUnit.Millimeter;
			e.Graphics.TranslateTransform(-(float)nPageX * (float)dblPageWidth, -(float)nPageY * (float)dblPageHeight);

			DrawBellows(e.Graphics);
			if (nPage+1 < nPages )
			{
				nPage++;
				e.HasMorePages = true;
			}
		}

		private void btnPageSetup_Click(object sender, EventArgs e)
		{
			pageSetupDialog1.Document = printDocument1;
			pageSetupDialog1.ShowDialog();
		}

		private void printDocument1_BeginPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
		{
			nPage = 0;
		}

		private void StoreItems()
		{
			if (m_CurrentElement != null)
			{
				m_CurrentElement.Inversions = (int)cboInversions.SelectedItem;
				m_CurrentElement.BellowsShape = (BellowsConfigElement.EBellowsShape)cboShape.SelectedItem;
				m_CurrentElement.FoldWidth = Double.Parse(txtFoldWidth.Text);
				m_CurrentElement.Height = Double.Parse(txtHeight.Text);
				m_CurrentElement.Width = Double.Parse(txtWidth.Text);
				m_CurrentElement.Length = Double.Parse(txtLength.Text);
				m_CurrentElement.MountFolds = Int32.Parse(txtMountFolds.Text);
				m_CurrentElement.AlternateFolds = chkAlternateFolds.Checked;
			}
		}

		private void cboConfig_SelectedIndexChanged(object sender, EventArgs e)
		{
			// Store old values
			StoreItems();
			// Load new values
			m_CurrentElement = (BellowsConfigElement)(((ComboBox)sender).SelectedItem);

			cboInversions.SelectedItem = m_CurrentElement.Inversions;
			cboShape.SelectedItem = m_CurrentElement.BellowsShape;
			txtFoldWidth.Text = m_CurrentElement.FoldWidth.ToString();
			txtHeight.Text = m_CurrentElement.Height.ToString();
			txtWidth.Text = m_CurrentElement.Width.ToString();
			txtLength.Text = m_CurrentElement.Length.ToString();
			txtMountFolds.Text = m_CurrentElement.MountFolds.ToString();
			chkAlternateFolds.Checked = m_CurrentElement.AlternateFolds;
		}

		private void Form1_FormClosing(object sender, FormClosingEventArgs e)
		{
			StoreItems();
			((BellowConfig)m_Config.Sections["BellowConfig"]).SelectedItem = cboConfig.SelectedItem.ToString();
			m_Config.Save(ConfigurationSaveMode.Full);
		}

		private void btnNewConfig_Click(object sender, EventArgs ev)
		{
			NewName frm = new NewName();
			if ( frm.ShowDialog(this) == DialogResult.OK )
			{
				BellowsCollection col = ((BellowConfig)m_Config.Sections["BellowConfig"]).Bellows;
				if (col[frm.NameText] != null)
				{
					MessageBox.Show(this,"Configuration '" + frm.NameText + "' already exists");
				}
				else
				{
					BellowsConfigElement e = new BellowsConfigElement();
					e.Name = frm.NameText;
					col.Add(e);
					cboConfig.Items.Add( e );
					cboConfig.SelectedItem = e;
				}
			}
		}

		private void cboShape_SelectedIndexChanged(object sender, EventArgs e)
		{
			UpdateCalculations();
		}

		private void cboInversions_SelectedIndexChanged(object sender, EventArgs e)
		{
			UpdateCalculations();
		}

		private void chkAlternateFolds_CheckedChanged(object sender, EventArgs e)
		{
			UpdateCalculations();
		}

		private void txtMountFolds_Leave(object sender, EventArgs e)
		{
			UpdateCalculations();
		}

		private void txtWidth_Leave(object sender, EventArgs e)
		{
			UpdateCalculations();
		}

		private void txtHeight_Leave(object sender, EventArgs e)
		{
			UpdateCalculations();
		}

		private void txtLength_Leave(object sender, EventArgs e)
		{
			UpdateCalculations();
		}

		private void txtFoldWidth_Leave(object sender, EventArgs e)
		{
			UpdateCalculations();
		}

        private void btnGCode_Click(object sender, EventArgs e)
        {
            GenerateGCode dlg = new GenerateGCode();
            if ( dlg.ShowDialog(this) == DialogResult.OK )
            {
            }

            string sFilename = @"c:\temp\Bellows";
            double dCutterOffset = 0.75;

        }

	}
}